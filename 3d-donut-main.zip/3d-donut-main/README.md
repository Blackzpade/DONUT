# 3D Spinning Donut Code in C

![](output.gif)




### "Donut math: how donut.c works" blog post by *Andy Sloane*:
https://www.a1k0n.net/2011/07/20/donut-math.html
